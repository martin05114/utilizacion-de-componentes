﻿namespace pdf_media_web
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.titulo = new System.Windows.Forms.Label();
            this.PDF = new System.Windows.Forms.Button();
            this.Reproductor = new System.Windows.Forms.Button();
            this.Navegador = new System.Windows.Forms.Button();
            this.btncerrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titulo
            // 
            this.titulo.AutoSize = true;
            this.titulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titulo.Location = new System.Drawing.Point(210, 40);
            this.titulo.Name = "titulo";
            this.titulo.Size = new System.Drawing.Size(349, 37);
            this.titulo.TabIndex = 0;
            this.titulo.Text = "¿ Que deseas hacer ?";
            // 
            // PDF
            // 
            this.PDF.Location = new System.Drawing.Point(165, 183);
            this.PDF.Name = "PDF";
            this.PDF.Size = new System.Drawing.Size(103, 35);
            this.PDF.TabIndex = 1;
            this.PDF.Text = "PDF";
            this.PDF.UseVisualStyleBackColor = true;
            this.PDF.Click += new System.EventHandler(this.PDF_Click);
            // 
            // Reproductor
            // 
            this.Reproductor.Location = new System.Drawing.Point(330, 183);
            this.Reproductor.Name = "Reproductor";
            this.Reproductor.Size = new System.Drawing.Size(134, 35);
            this.Reproductor.TabIndex = 2;
            this.Reproductor.Text = "Reproductor";
            this.Reproductor.UseVisualStyleBackColor = true;
            this.Reproductor.Click += new System.EventHandler(this.Reproductor_Click);
            // 
            // Navegador
            // 
            this.Navegador.Location = new System.Drawing.Point(482, 183);
            this.Navegador.Name = "Navegador";
            this.Navegador.Size = new System.Drawing.Size(114, 35);
            this.Navegador.TabIndex = 3;
            this.Navegador.Text = "Navegador";
            this.Navegador.UseVisualStyleBackColor = true;
            this.Navegador.Click += new System.EventHandler(this.Navegador_Click);
            // 
            // btncerrar
            // 
            this.btncerrar.Location = new System.Drawing.Point(330, 288);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(75, 33);
            this.btncerrar.TabIndex = 4;
            this.btncerrar.Text = "Cerrar";
            this.btncerrar.UseVisualStyleBackColor = true;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btncerrar);
            this.Controls.Add(this.Navegador);
            this.Controls.Add(this.Reproductor);
            this.Controls.Add(this.PDF);
            this.Controls.Add(this.titulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titulo;
        private System.Windows.Forms.Button PDF;
        private System.Windows.Forms.Button Reproductor;
        private System.Windows.Forms.Button Navegador;
        private System.Windows.Forms.Button btncerrar;
    }
}

