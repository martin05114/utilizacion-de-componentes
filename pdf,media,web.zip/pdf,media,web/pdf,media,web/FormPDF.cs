﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pdf_media_web
{
    public partial class FormPDF : Form
    {
        public FormPDF()
        {
            InitializeComponent();

        }

       private void button1_Click(object sender, EventArgs e)
        {
            string pdfPath = @"C:\Users\marti\OneDrive\Escritorio\pdf,media,web\introcs.PDF";
            if (System.IO.File.Exists(pdfPath))
            {
                
                this.axAcroPDF1.LoadFile(pdfPath);
            }
        }

        private void btnvolver_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
    }
}
