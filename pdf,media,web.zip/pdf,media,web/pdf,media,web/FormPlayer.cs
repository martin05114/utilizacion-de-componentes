﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pdf_media_web
{
    public partial class FormPlayer : Form
    {
        public FormPlayer()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string archivoMultimedia = @"C:\Users\marti\OneDrive\Escritorio\pdf,media,web\La Cama Vacía, Oscar Agudelo - Video Oficial (1).mp4"; // Cambia esto a la ruta de tu archivo
                                                        
            axWindowsMediaPlayer1.URL = archivoMultimedia; 
            axWindowsMediaPlayer1.Ctlcontrols.play(); 


        }

        private void btnvolver_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
    }
}