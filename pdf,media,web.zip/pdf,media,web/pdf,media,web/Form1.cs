﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pdf_media_web
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void PDF_Click(object sender, EventArgs e)
        {
            FormPDF pdfForm = new FormPDF();
            pdfForm.Show();
            this.Hide();

        }

        private void Reproductor_Click(object sender, EventArgs e)
        {
            FormPlayer playerForm = new FormPlayer();
            playerForm.Show();
            this.Hide();
        }

        private void Navegador_Click(object sender, EventArgs e)
        {
            FormBrowser browserForm = new FormBrowser();
            browserForm.Show();
            this.Hide();
        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

}
